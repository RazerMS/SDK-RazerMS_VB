﻿Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected demo_type As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        demo_type = "sandbox"
    End Sub

End Class