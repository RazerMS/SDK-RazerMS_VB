﻿Imports System.Web
Imports System.Web.Services

Public Class seamlessHandler
    Implements System.Web.IHttpHandler
    Protected rand As System.Random = New System.Random()
    Protected randNum As String = ""
    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest

        Dim obj As New MolPayCS.Seamlesspayment
        obj.Merchantid = "MOLPay_seamless_Dev"  'replace with your own Merchant ID 
        obj.Vkey = "2602770db42d768eafac407eb7a92e14" 'replace with your own Vkey
        randNum = rand.Next(1, 1000)
        obj.Orderid = randNum
        obj.Country = "MY"
        obj.ReturnUrl = ""
        obj.ProcessRequest()

    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class